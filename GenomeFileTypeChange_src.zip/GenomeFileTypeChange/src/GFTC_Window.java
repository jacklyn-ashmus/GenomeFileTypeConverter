import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JProgressBar;

public class GFTC_Window extends JFrame {

	private JPanel contentPane;
	private JTextField inFilePathField;
	private JTextField outFilePathField;

	static boolean inputIs_ftDNA = false;
	static boolean inputIs_ancestryDNA = false;
	static boolean inputIs_23AndMe = false;
	static boolean inputIs_diagnomics = false;
	static String inFilePath = "";
	static String outFilePath = "";
	static boolean outputIs_ftDNA = false;
	static boolean outputIs_ancestryDNA = false;
	static boolean outputIs_23AndMe = false;
	static boolean outputIs_diagnomics = false;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GFTC_Window frame = new GFTC_Window();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GFTC_Window() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 445);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblImportFileType = new JLabel("Input File Type:");
		lblImportFileType.setBounds(15, 16, 137, 26);
		contentPane.add(lblImportFileType);
		
		ButtonGroup inButtonGroup = new ButtonGroup();
		ButtonGroup outButtonGroup = new ButtonGroup();
		 
		JRadioButton ftDNAInputButton = new JRadioButton("ftDNA");
		ftDNAInputButton.setBounds(15, 46, 90, 29);
		contentPane.add(ftDNAInputButton);
		
		JRadioButton ancestryDNAInputButton = new JRadioButton("AncestryDNA");
		ancestryDNAInputButton.setBounds(133, 46, 155, 29);
		contentPane.add(ancestryDNAInputButton);
		
		JRadioButton twenAndMeInputButton = new JRadioButton("23AndMe");
		twenAndMeInputButton.setBounds(11, 83, 109, 29);
		contentPane.add(twenAndMeInputButton);
		
	//	JRadioButton diagnomicsInputButton = new JRadioButton("Diagnomics");
	//	diagnomicsInputButton.setBounds(133, 83, 155, 29);
	//	contentPane.add(diagnomicsInputButton);
		
		JRadioButton ftDNAOutputButton = new JRadioButton("ftDNA");
		ftDNAOutputButton.setBounds(391, 46, 80, 29);
		contentPane.add(ftDNAOutputButton);
		
		JRadioButton ancestryDNAOutputButton = new JRadioButton("AncestryDNA");
		ancestryDNAOutputButton.setBounds(510, 46, 155, 29);
		contentPane.add(ancestryDNAOutputButton);
		
		JRadioButton twenAndMeOutputButton = new JRadioButton("23AndMe");
		twenAndMeOutputButton.setBounds(391, 83, 109, 29);
		contentPane.add(twenAndMeOutputButton);
		
	//	JRadioButton diagnomicsOutputButton = new JRadioButton("Diagnomics");
	//	diagnomicsOutputButton.setBounds(510, 83, 155, 29);
	//	contentPane.add(diagnomicsOutputButton);
		
		JLabel lblOutputFileType = new JLabel("Output File Type:");
		lblOutputFileType.setBounds(381, 19, 155, 20);
		contentPane.add(lblOutputFileType);
		
		inFilePathField = new JTextField();
		inFilePathField.setBounds(15, 182, 306, 26);
		contentPane.add(inFilePathField);
		inFilePathField.setColumns(10);
		
		outFilePathField = new JTextField();
		outFilePathField.setColumns(10);
		outFilePathField.setBounds(381, 182, 306, 26);
		contentPane.add(outFilePathField);
		
		JLabel lblInputFilePath = new JLabel("Input File Path:");
		lblInputFilePath.setBounds(15, 146, 175, 20);
		contentPane.add(lblInputFilePath);
		
		JLabel lblOutputFilePath = new JLabel("Output File Path:");
		lblOutputFilePath.setBounds(381, 146, 155, 20);
		contentPane.add(lblOutputFilePath);
		
		JLabel lblNoteFilePaths = new JLabel("Note: File paths must be entered with whole path and forward slashes");
		lblNoteFilePaths.setBounds(25, 212, 495, 20);
		contentPane.add(lblNoteFilePaths);
		
		JLabel lblExChomefolderfolderancestryfilecsv = new JLabel("Ex.: C:/Home/folder/folder/ancestryFile.csv");
		lblExChomefolderfolderancestryfilecsv.setBounds(51, 236, 399, 20);
		contentPane.add(lblExChomefolderfolderancestryfilecsv);
		
		JButton btnRunProgram = new JButton("Run Program");
		btnRunProgram.setBounds(282, 333, 189, 47);
		contentPane.add(btnRunProgram);
		
		
	//	inButtonGroup.add(diagnomicsInputButton);
		inButtonGroup.add(twenAndMeInputButton);
		inButtonGroup.add(ancestryDNAInputButton);
		inButtonGroup.add(ftDNAInputButton);
		
	//	outButtonGroup.add(diagnomicsOutputButton);
		outButtonGroup.add(twenAndMeOutputButton);
		outButtonGroup.add(ancestryDNAOutputButton);
		outButtonGroup.add(ftDNAOutputButton);
		
		JLabel lblAlsoFtdnaAnd = new JLabel("Also, ftDNA and MyHeritage formats are identical, so just select \"ftDNA\" to");
		lblAlsoFtdnaAnd.setBounds(35, 258, 565, 20);
		contentPane.add(lblAlsoFtdnaAnd);
		
		JLabel lblConvertToOr = new JLabel(" convert to or from MyHeritage files");
		lblConvertToOr.setBounds(61, 281, 505, 20);
		contentPane.add(lblConvertToOr);
		
		
		btnRunProgram.addActionListener(new ActionListener() { 
			@Override
			public void actionPerformed(ActionEvent arg0) {
			//	inputIs_diagnomics = diagnomicsInputButton.isSelected();
				inputIs_23AndMe = twenAndMeInputButton.isSelected();
				inputIs_ancestryDNA = ancestryDNAInputButton.isSelected();
				inputIs_ftDNA = ftDNAInputButton.isSelected();
				
			//	outputIs_diagnomics = diagnomicsOutputButton.isSelected();
				outputIs_23AndMe = twenAndMeOutputButton.isSelected();
				outputIs_ancestryDNA = ancestryDNAOutputButton.isSelected();
				outputIs_ftDNA = ftDNAOutputButton.isSelected();
				
				
				inFilePath = inFilePathField.getText();
				outFilePath = outFilePathField.getText();
				
				
				try {
					processFile();
					JOptionPane.showMessageDialog(null, "Done!");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					JOptionPane.showMessageDialog(null, "Couldn't process file.");

				}
				
				
			} 
				} );
		
	}
	
	
	
	private static void processFile ( ) throws IOException{
		System.out.println(inFilePath);
		UserEntry[] user = GFTC_03_ImportUserFile.userImport( inputIs_23AndMe, inputIs_ancestryDNA, 
				inputIs_ftDNA , false, false, false, false, false, inputIs_diagnomics, inFilePath);
		
		System.out.println("# of user entries = " + user.length);
		
		File outFile = new File(outFilePath);
		FileWriter fw = new FileWriter(outFile);
		BufferedWriter bw = new BufferedWriter (fw);
		/*
		 * The file format for an AncestryDNA raw data file differs from the 23andMe file format		
			The results are given in two columns called Allele1 and Allele2, while 23andMe combines these 
			into one column called genotype, with the alleles in alphabetical order.	
				
				Note: Allele1 and Allele2 do NOT represent phased data -- they are in the order given by 
				Illumina's base-calling software.
			AncestryDNA uses 0 for no-calls, while 23andMe uses a dash (-).	
			Ancestry DNA uses the number 23 for X chromosome SNPs, 24 for Y chromosome SNPs, and 
			25 for XY SNPs. 23andMe includes XY SNPs with the X portion of the file.	

		 */
		
		
		if (outputIs_diagnomics){	}
		
		if (outputIs_23AndMe){
			System.out.println("outputIs_23AndMe");
			twenAndMeOut(user, bw);
			
		}
		
		if (outputIs_ancestryDNA){
			System.out.println("outputIs_ancestryDNA");
			ancestryOut(user, bw);
		
			
		}

		if (outputIs_ftDNA){
				
			System.out.println("outputIs_ftDNA");
				ftDNAOut(user, bw);
				
		}
		
		
		
		
		bw.close();
	}
	
	
	private static void twenAndMeOut(UserEntry[] user, BufferedWriter bw) throws IOException{
		// 23andMe
		// rsid	chromosome	position	genotype
			// tab separated
		
		bw.write("# 23andMe reformatted File\n");
		if (inputIs_ancestryDNA){
			System.out.println("inputIs_ancestryDNA");
			bw.write("# original file type = ancestryDNA\n# Header stuff");
			bw.write("#rsid\tchromosome\tposition\tgenotype\n");
			ancestry_2_23AndMe(user, bw);
		}
		if (inputIs_ftDNA){
			System.out.println("inputIs_ftDNA");
			bw.write("# original file type = ftDNA\n# Header stuff");
			bw.write("#rsid\tchromosome\tposition\tgenotype\n");
			ancestry_2_23AndMe(user, bw);
		}
		
	}
	
	private static void ancestryOut  (UserEntry[] user, BufferedWriter bw) throws IOException{
		bw.write("# Ancestry DNA reformatted File\n");
		// ancestyDNA
		//	rsid	chromosome	position	allele1	allele2
			// tab separated
		if (inputIs_23AndMe){
			System.out.println("inputIs_23AndMe");
			bw.write("# original file type = 23AndMe\n# Header stuff");
			bw.write("rsid\tchromosome\tposition\tallele1\tallele2\n");
			twenAndMe_2_ancestry(user, bw);
		}
		if (inputIs_ftDNA){
			System.out.println("inputIs_ftDNA");
			bw.write("# original file type = ftDNA\n# Header stuff");
			bw.write("rsid\tchromosome\tposition\tallele1\tallele2\n");
			twenAndMe_2_ancestry(user, bw);
		}
	}
	
	
	private static void ftDNAOut  (UserEntry[] user, BufferedWriter bw) throws IOException{
		// familyfinder
		// rsid	chromosome	position	result (genotype)
			// csv
		if (inputIs_23AndMe){
			System.out.println("inputIs_23AndMe");
			bw.write("# original file type = 23AndMe\n# Header stuff");
			bw.write("RSID,CHROMOSOME,POSITION,RESULT\n");
			ancestry_2_ftDNA(user, bw);
		}
		if (inputIs_ancestryDNA){
			System.out.println("inputIs_ancestryDNA");
			bw.write("# original file type = ancestryDNA\n# Header stuff");
			bw.write("RSID,CHROMOSOME,POSITION,RESULT\n");
			ancestry_2_ftDNA(user, bw);
		}
		
	}
	
	
	private static void twenAndMe_2_ancestry (UserEntry[] user, BufferedWriter bw) throws IOException{
		for (int i = 0; i < user.length; i++){
			String rsTemp = user[i].rsNum.trim();
			String chromTemp = user[i].chrom_String.trim();
			int position = user[i].position;
			char[] alleles = user[i].genotype.trim().toCharArray();
			String a1 = "";
			String a2 = "";
			if ( alleles.length > 1){
				a1 = alleles[0] + "";
				a2 = alleles[1] + "";
			}
			
			if ( a1.equals("-")){	a1 = 0 + "";	}
			if ( a2.equals("-")){	a2 = 0 + "";	}
			if (chromTemp.equals("Y")){	chromTemp = 24 + "";	}
			if (chromTemp.equals("XY")){	chromTemp = 25 + "";	}
			if (chromTemp.equals("X")){	chromTemp = 23 + "";	}
			/*
			 * AncestryDNA uses 0 for no-calls, while 23andMe uses a dash (-).	
				Ancestry DNA uses the number 23 for X chromosome SNPs, 24 for Y chromosome SNPs, and 
				25 for XY SNPs. 23andMe includes XY SNPs with the X portion of the file.	
			 */
			bw.write(rsTemp + "\t" + chromTemp+ "\t" + position+ "\t" + a1+ "\t" + a2 + "\n");
			System.out.println("out line = " + i + "\t\t" + rsTemp + "\t" + chromTemp+ "\t" + position+ "\t" + a1+ "\t" + a2 );
		}
	}
	
	
	private static void ancestry_2_23AndMe (UserEntry[] user, BufferedWriter bw) throws IOException{
		for (int i = 0; i < user.length; i++){
			String rsTemp = user[i].rsNum.trim();
			String chromTemp = user[i].chrom_String.trim();
			int position = user[i].position;
			char[] alleles = user[i].genotype.trim().toCharArray();
			String a1 = "";
			String a2 = "";
			if ( alleles.length > 1){
				a1 = alleles[0] + "";
				a2 = alleles[1] + "";
			}
			
			if ( a1.equals("0")){	a1 = "-";	}
			if ( a2.equals("0")){	a2 = "-";	}
			if (chromTemp.equals("24")){	chromTemp = "Y";	}
			if (chromTemp.equals("25")){	chromTemp = "XY";	}
			if (chromTemp.equals("23")){	chromTemp = "X";	}
			/*
			 * AncestryDNA uses 0 for no-calls, while 23andMe uses a dash (-).	
				Ancestry DNA uses the number 23 for X chromosome SNPs, 24 for Y chromosome SNPs, and 
				25 for XY SNPs. 23andMe includes XY SNPs with the X portion of the file.	
			 */
			bw.write(rsTemp + "\t" + chromTemp+ "\t" + position+ "\t" + a1 + a2 + "\n");
			System.out.println("out line = " + i + "\t\t" + rsTemp + "\t" + chromTemp+ "\t" + position+ "\t" + a1 + a2  );
		}
	}
	
	private static void ancestry_2_ftDNA (UserEntry[] user, BufferedWriter bw) throws IOException{
		for (int i = 0; i < user.length; i++){
			String rsTemp = user[i].rsNum.trim();
			String chromTemp = user[i].chrom_String.trim();
			int position = user[i].position;
			char[] alleles = user[i].genotype.trim().toCharArray();
			String a1 = "";
			String a2 = "";
			if ( alleles.length > 1){
				a1 = alleles[0] + "";
				a2 = alleles[1] + "";
			}
			
			if ( a1.equals("0")){	a1 = "-";	}
			if ( a2.equals("0")){	a2 = "-";	}
			if (chromTemp.equals("24")){	chromTemp = "Y";	}
			if (chromTemp.equals("25")){	chromTemp = "XY";	}
			if (chromTemp.equals("23")){	chromTemp = "X";	}
			/*
			 * AncestryDNA uses 0 for no-calls, while 23andMe uses a dash (-).	
				Ancestry DNA uses the number 23 for X chromosome SNPs, 24 for Y chromosome SNPs, and 
				25 for XY SNPs. 23andMe includes XY SNPs with the X portion of the file.	
			 */
			bw.write(rsTemp + "," + chromTemp+ "," + position+ "," + a1 + a2 + "\n");
			System.out.println("out line = " + i + "\t\t" + rsTemp + "," + chromTemp+ "," + position+ "," + a1 + a2);
		}
	}
	
}
